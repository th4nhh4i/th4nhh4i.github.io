# Can You Remember 1 & 2 — Solver Source

Mã nguồn dùng cho writeup Security Bootcamp Đắk Lắk 2026.

## Cấu trúc

- `can-you-remember-1/`: các script xây database malware, nhận diện family, khám phá đồ thị và solver ban đầu để lấy Flag 1.
- `can-you-remember-2/`: các lần refine CSP, Active Learning, Live Verification và solver cuối đạt 100/100 để lấy Flag 2.

Các entry point đáng chú ý:

- `can-you-remember-1/run_csp.py`: mô hình CSP ban đầu.
- `can-you-remember-1/run_iter.py`: nhánh refinement đạt 94/100.
- `can-you-remember-2/solve_flag2.py`: solver cuối đạt 100/100.
- `can-you-remember-2/final_attempt.py`: phiên bản thử nghiệm trước solver cuối.

Gói này chỉ chứa source code và dữ liệu mô hình JSON. Không có mẫu malware, file ZIP thử thách, executable UPX hoặc thư mục `__pycache__`.

Một số script giữ lại đường dẫn cục bộ từ thời điểm thi nhằm bảo toàn lịch sử. Hãy cập nhật đường dẫn dữ liệu trước khi chạy trong môi trường khác.
