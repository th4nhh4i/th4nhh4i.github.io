"""Explorer v3 — 1-hop signature + structural constraints.

The graph is simple and 5-regular with two-way warps:
  * a node's 5 warps lead to 5 DISTINCT neighbours
  * if A -w-> B then B has EXACTLY ONE warp back to A
Both facts are free discriminators that stop the 1-hop signature from
merging two genuinely different hosts.
"""
import collections
NHOSTS=20

class Mapper:
    def __init__(s,g,verbose=True):
        s.g=g; s.v=verbose
        s.nodes=[]; s.path2n={}; s.childfam={}

    # ---------- candidate filtering ----------
    def _match(s,i,obs):
        ch=s.nodes[i]["ch"]
        return all(ch[w-1] is not None and ch[w-1]==v for w,v in obs.items())
    def _cands(s,fam,obs,Q=None,w=None):
        out=[]
        for i,n in enumerate(s.nodes):
            if n["fam"]!=fam or not s._match(i,obs): continue
            if Q is not None:
                # Q's five warps must reach five distinct nodes
                if any(s.nodes[Q]["nb"].get(x)==i for x in range(1,6) if x!=w): continue
                # i must be able to hold a warp back to Q
                qf=s.nodes[Q]["fam"]; ok=False
                for u in range(1,6):
                    cu=n["ch"][u-1]
                    if (cu is None or cu==qf) and n["nb"].get(u) in (None,Q): ok=True; break
                if not ok: continue
            out.append(i)
        return out
    def _best_warp(s,cands,obs):
        best=None; bs=-9
        for w in range(1,6):
            if w in obs: continue
            vals=collections.Counter(s.nodes[i]["ch"][w-1] for i in cands)
            sc=-0.5 if None in vals else len(vals)-max(vals.values())/max(1,len(cands))
            if sc>bs: bs=sc; best=w
        return best
    def famof(s,p):
        if p in s.childfam: return s.childfam[p]
        s.g.goto(p); f=s.g.look(); s.childfam[p]=f; return f

    # ---------- identification ----------
    def identify(s,p,full=False,minw=1):
        if p in s.path2n: return s.path2n[p]
        Q=s.path2n.get(p[:-1]) if p else None
        w=p[-1] if p else None
        f=s.famof(p)
        obs={}; ch=[None]*5
        cands=s._cands(f,obs,Q,w)
        if not cands: full=True
        while True:
            if full:
                nxt=next((x for x in range(1,6) if x not in obs),None)
            else:
                if len(cands)<=1 and len(obs)>=minw: break
                nxt=s._best_warp(cands,obs)
            if nxt is None: break
            s.g.goto(p); s.g.step(nxt)
            v=s.g.look(); obs[nxt]=v; ch[nxt-1]=v; s.childfam[p+(nxt,)]=v
            if not full:
                cands=s._cands(f,obs,Q,w)
                if not cands: full=True
        if not full and len(cands)==1:
            idx=cands[0]
        else:
            exact=[i for i in s._cands(f,obs,Q,w) if list(s.nodes[i]["ch"])==ch]
            if exact: idx=exact[0]
            else:
                idx=len(s.nodes); s.nodes.append({"fam":f,"path":p,"ch":ch,"nb":{}})
        s.path2n[p]=idx
        if Q is not None:
            s.nodes[Q]["nb"][w]=idx
            # register the reverse edge when it is unambiguous
            back=[u for u in range(1,6)
                  if s.nodes[idx]["ch"][u-1]==s.nodes[Q]["fam"] and s.nodes[idx]["nb"].get(u) in (None,Q)]
            if len(back)==1: s.nodes[idx]["nb"][back[0]]=Q
        if s.v:
            print("  %-14s -> node %2d fam=%-11s nodes=%2d moves=%s"%(
                ",".join(map(str,p)) or "-",idx,(f[:10] if f!="safe" else "safe"),
                len(s.nodes),s.g.moves),flush=True)
        return idx

    # ---------- phases ----------
    def discover(s,floor=120):
        q=[()]
        while q:
            if s.g.moves is not None and s.g.moves<floor:
                if s.v: print("  discovery floor",s.g.moves,flush=True); break
            if len(s.nodes)>=NHOSTS: break
            cnt=collections.Counter(n["fam"] for n in s.nodes)
            q.sort(key=lambda p:(cnt.get(s.childfam.get(p),0),len(p)))
            p=q.pop(0)
            if p in s.path2n: continue
            before=len(s.nodes)
            s.identify(p,full=(p==()),minw=2)
            if len(s.nodes)>before:
                for x in range(1,6): q.append(p+(x,))
        for p,i in s.path2n.items():
            for x in range(1,6):
                c=p+(x,)
                if c in s.path2n: s.nodes[i]["nb"][x]=s.path2n[c]

    def close_edges(s,floor=45):
        byfam=collections.defaultdict(list)
        for i,n in enumerate(s.nodes): byfam[n["fam"]].append(i)
        pend=[]
        for i,n in enumerate(s.nodes):
            for w in range(1,6):
                if n["nb"].get(w) is not None: continue
                cf=n["ch"][w-1]
                cand=[j for j in byfam.get(cf,[])
                      if not any(n["nb"].get(x)==j for x in range(1,6) if x!=w)]
                if len(cand)==1: n["nb"][w]=cand[0]; continue
                pend.append((i,w))
        pend.sort(key=lambda t: len(s.nodes[t[0]]["path"]))
        if s.v: print("  edges needing a visit:",len(pend),flush=True)
        for (i,w) in pend:
            if s.g.moves<floor:
                if s.v: print("  budget stop",flush=True); break
            if s.nodes[i]["nb"].get(w) is not None: continue
            s.nodes[i]["nb"][w]=s.identify(s.nodes[i]["path"]+(w,),minw=5)
        return sum(1 for n in s.nodes for w in range(1,6) if n["nb"].get(w) is None)

    def consistency(s):
        dup=sum(1 for n in s.nodes
                if len({n["nb"].get(w) for w in range(1,6) if n["nb"].get(w) is not None})
                   != len([w for w in range(1,6) if n["nb"].get(w) is not None]))
        asym=0
        for i,n in enumerate(s.nodes):
            for w in range(1,6):
                j=n["nb"].get(w)
                if j is None: continue
                if sum(1 for u in range(1,6) if s.nodes[j]["nb"].get(u)==i)!=1: asym+=1
        return dup,asym

def walk_predict(nodes,route):
    cur=0; out=[nodes[0]["fam"]]
    for w in route:
        nx=nodes[cur]["nb"].get(w)
        if nx is None: return None
        cur=nx; out.append(nodes[cur]["fam"])
    return out
