import json,time,random
import solve, explore7
from solve import Game, FAM, parse_route

BASE=solve.BASE

def csp(nodes,fixed,observed=None):
    n=len(nodes); fam=[x["fam"] for x in nodes]
    ports=[(i,w) for i in range(n) for w in range(5)]
    fixed=dict(fixed)
    def compat(p,q,target):
        i,w=p; j,u=q
        if i==j: return False
        if fam[j]!=nodes[i]["ch"][w]: return False
        if fam[i]!=nodes[j]["ch"][u]: return False
        if fixed.get(p,j)!=j or fixed.get(q,i)!=i: return False
        if j in target[i] or i in target[j]: return False
        return True
    pairdom={}
    for p in ports:
        pairdom[p]=[]
        for q in ports:
            if q==p: continue
            i,w=p; j,u=q
            if i==j: continue
            if fam[j]==nodes[i]["ch"][w] and fam[i]==nodes[j]["ch"][u]:
                pairdom[p].append(q)
    target=[set() for _ in range(n)]
    assign={}
    calls=[0]
    def dfs(left):
        calls[0]+=1
        if calls[0]>250000: return False
        if not left:
            if observed:
                for p,seq in observed.items():
                    cur=0
                    if fam[cur]!=seq[0]: return False
                    for k,w in enumerate(p,1):
                        cur=assign[(cur,w-1)]
                        if fam[cur]!=seq[k]: return False
            return True
        best=None; opts=None
        for p in left:
            op=[q for q in pairdom[p] if q in left and compat(p,q,target)]
            if opts is None or len(op)<len(opts):
                best,opts=p,op
                if not opts: return False
                if len(opts)==1: break
        p=best; i,w=p
        # Prefer the partner with the fewest remaining alternatives.
        opts.sort(key=lambda q: len([z for z in pairdom[q] if z in left]))
        for q in opts:
            j,u=q
            target[i].add(j); target[j].add(i)
            assign[p]=j; assign[q]=i
            rem=left-{p,q}; ok=True
            for r in rem:
                if not any(s in rem and compat(r,s,target) for s in pairdom[r]):
                    ok=False; break
            if ok and dfs(rem): return True
            target[i].remove(j); target[j].remove(i)
            del assign[p]; del assign[q]
        return False
    ok=dfs(set(ports))
    return [[assign[(i,w)] for w in range(5)] for i in range(n)] if ok else None

def observed_fixed(M):
    out={}
    for i,n in enumerate(M.nodes):
        for w,j in n.get("nb",{}).items(): out[(i,int(w)-1)]=j
    return out

def check_paths(M,edges):
    bad=[]
    for p,want in M.path2n.items():
        cur=0
        for w in p:
            if (cur,w-1) not in edges: cur=None; break
            cur=edges[(cur,w-1)]
        if cur is not None and cur!=want: bad.append((p,want,cur))
    return bad

def walk(edges,nodes,route):
    cur=0; out=[nodes[cur]["fam"]]
    for w in route:
        cur=edges.get((cur,w-1))
        if cur is None: return None
        out.append(nodes[cur]["fam"])
    return out

def main():
    g=Game(); print("instance",g.I.id,time.strftime("%H:%M:%S"),flush=True)
    M=explore7.Mapper(g); M.discover()
    print("discovered",len(M.nodes),"moves",g.moves,"dl",g.dl,flush=True)
    if len(M.nodes)<20: print("not enough nodes"); return
    observed={}
    for p in M.path2n:
        seq=[]
        for k in range(len(p)+1):
            q=p[:k]
            v=M.g.pathfam.get(q)
            if v is None: v=M.childfam.get(q)
            if v is None: v=M.nodes[M.path2n[q]]["fam"]
            seq.append(v)
        observed[p]=seq
    raw=observed_fixed(M)
    # Try all observed edge claims first. If a tentative identification made
    # the constraints inconsistent, retain the deepest feasible prefix of claims.
    edges=csp(M.nodes,raw,observed)
    if edges is None:
        items=sorted(raw, key=lambda e: len(M.nodes[e[0]]["path"]))
        kept={}
        for e in items:
            trial=dict(kept); trial[e]=raw[e]
            if csp(M.nodes,trial,observed) is not None: kept[e]=raw[e]
        raw=kept; edges=csp(M.nodes,raw,observed)
    if edges is None:
        print("CSP failed",flush=True); return
    ed={(i,w):edges[i][w] for i in range(len(edges)) for w in range(5)}
    print("csp ok fixed",len(raw),"path mismatches",len(check_paths(M,ed)),"moves",g.moves,flush=True)
    for t in range(8):
        route=[random.randint(1,5) for _ in range(6)]
        pred=walk(ed,M.nodes,route)
        g.I.reset(); g.here=(); obs=[g.look()]
        for w in route:
            f=g.look()
            if f!="safe":
                if not g.I.classify(FAM[f]).get("correct"): print("classify fail"); return
            g.I.move(w); g.here+= (w,); obs.append(g.look())
        print("verify",route,"ok",obs==pred,flush=True)
        if obs!=pred: print("pred",pred,"obs",obs); return
    qs=g.I.s.post(BASE+"/sanity-check/questions").json()
    ans={}
    for q in qs:
        route=parse_route(q["route_map"]); seq=walk(ed,M.nodes,route)
        if seq is None: print("unresolved",q["id"]); return
        slugs=["safe" if f=="safe" else FAM[f] for f in seq]
        ans[q["id"]]=slugs if isinstance(q["answer_example"],list) else slugs[-1]
    r=g.I.s.post(BASE+"/sanity-check/submit",json=ans)
    print(r.status_code,r.text,flush=True)
    json.dump(ans,open("answers.json","w"),indent=1)
    open("result.json","w").write(r.text)

if __name__ == "__main__":
    main()
