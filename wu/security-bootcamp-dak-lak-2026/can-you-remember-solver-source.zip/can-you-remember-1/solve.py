"""Full explorer + sanity-check solver for 'Can You Remember'."""
import json,os,sys,time,random,collections
from ctf import Inst
from ident import Ident,inner

BASE="http://103.70.12.125:26001"
FAM=json.load(open("famdb.json"))          # cluster id -> slug
IDT=Ident()

class Game:
    def __init__(s, iid=None):
        s.I=Inst(iid); s.here=(); s.pathfam={}    # path tuple -> cluster|'safe'
        s.dl=0; s.unknown=[]
    @property
    def moves(s): return s.I.moves
    def look(s):
        """family of current host, cached by path"""
        p=s.here
        if p in s.pathfam: return s.pathfam[p]
        c=s.I.cur()
        if c["sample_url"] is None:
            s.pathfam[p]="safe"; return "safe"
        blob=s.I.fetch(c["sample_url"]); s.dl+=1
        cid,sc=IDT.cid(inner(blob))
        if cid is None:
            import hashlib
            d=inner(blob); h=hashlib.sha256(d).hexdigest()
            os.makedirs("newbins",exist_ok=True)
            open("newbins/%s.bin"%h,"wb").write(d)
            raise RuntimeError("UNKNOWN sample %s score=%.2f at %s"%(h[:16],sc,p))
        s.pathfam[p]=cid; return cid
    def step(s,w):
        f=s.look()
        if f!="safe":
            slug=FAM.get(f)
            if slug is None: raise RuntimeError("no slug for %s"%f[:12])
            r=s.I.classify(slug)
            if not r.get("correct"):
                raise RuntimeError("WRONG SLUG %s (hearts %s)"%(slug,r.get("hearts")))
        s.I.move(w); s.here=s.here+(w,)
    def goto(s,path):
        path=tuple(path)
        if s.here==path: return
        if len(path)>=len(s.here) and path[:len(s.here)]==s.here:
            for w in path[len(s.here):]: s.step(w)
            return
        s.I.reset(); s.here=()
        for w in path: s.step(w)

def explore(g, budget=940, verbose=True):
    nodes=[]            # each: {"fam":..., "path":tuple, "nb":{w:nodeidx or None}}
    sig2n={}
    path2n={}
    def probe(path):
        """returns (fam, [fam of child via w for w=1..5])"""
        g.goto(path); f=g.look()
        ch=[]
        for w in range(1,6):
            g.goto(path); g.step(w); ch.append(g.look())
        return f,tuple(ch)
    q=collections.deque([()])
    while q:
        if g.moves is not None and g.moves<60:
            if verbose: print("  !! move budget low",g.moves); break
        p=q.popleft()
        if p in path2n: continue
        f,ch=probe(p)
        sig=(f,ch)
        if sig in sig2n:
            path2n[p]=sig2n[sig]
        else:
            idx=len(nodes); nodes.append({"fam":f,"path":p,"nb":{},"ch":ch})
            sig2n[sig]=idx; path2n[p]=idx
            for w in range(1,6): q.append(p+(w,))
        if verbose:
            print("  path %-14s node=%2d fam=%-12s moves=%s"%(
                ",".join(map(str,p)) or "-", path2n[p], (f[:10] if f!="safe" else "safe"), g.moves),flush=True)
    # link edges
    for p,idx in path2n.items():
        for w in range(1,6):
            c=p+(w,)
            if c in path2n: nodes[idx]["nb"][w]=path2n[c]
    return nodes,path2n

def resolve(nodes):
    """fill missing nb entries using child family + uniqueness"""
    byfam=collections.defaultdict(list)
    for i,n in enumerate(nodes): byfam[n["fam"]].append(i)
    amb=0
    for i,n in enumerate(nodes):
        for w in range(1,6):
            if n["nb"].get(w) is None:
                cf=n["ch"][w-1]
                cands=byfam.get(cf,[])
                if len(cands)==1: n["nb"][w]=cands[0]
                else: amb+=1
    return amb

def walk_predict(nodes,route):
    cur=0; out=[nodes[0]["fam"]]
    for w in route:
        nx=nodes[cur]["nb"].get(w)
        if nx is None: return None
        cur=nx; out.append(nodes[cur]["fam"])
    return out

def parse_route(rm):
    return [int(x.strip().split()[-1]) for x in rm.split("->")]

def answer_all(g,nodes,FAMSLUG):
    qs=g.I.s.post(BASE+"/sanity-check/questions").json()
    json.dump(qs,open("questions.json","w"),indent=1)
    ans={}
    miss=0
    for q in qs:
        r=parse_route(q["route_map"])
        seq=walk_predict(nodes,r)
        if seq is None:
            miss+=1
            seq=[nodes[0]["fam"]]+["wannacry"]*len(r)
            seq=[x if x=="safe" else x for x in seq]
        slugs=[("safe" if f=="safe" else FAMSLUG.get(f,"wannacry")) for f in seq]
        if isinstance(q["answer_example"],list): ans[q["id"]]=slugs
        else: ans[q["id"]]=slugs[-1]
    print("unresolved routes:",miss)
    json.dump(ans,open("answers.json","w"),indent=1)
    r=g.I.s.post(BASE+"/sanity-check/submit",json=ans)
    print(r.status_code); print(r.text[:3000])
    open("result.json","w").write(r.text)
    return r.text

def verify(g,nodes,path2n,n=6,L=8):
    bad=0
    for _ in range(n):
        if g.moves<L+6: break
        route=[random.randint(1,5) for _ in range(L)]
        pred=walk_predict(nodes,route)
        if pred is None: print("  verify: unresolved route"); bad+=1; continue
        g.I.reset(); g.here=()
        obs=[g.look()]
        ok=True
        for i,w in enumerate(route):
            f=g.look()
            if f!="safe":
                res=g.I.classify(FAM[f])
                if not res.get("correct"): print("  verify classify fail"); ok=False; break
            g.I.move(w); g.here=g.here+(w,)
            # look() uses path cache; clear to force fresh read when path unseen
            f2=g.look(); obs.append(f2)
        if not ok: bad+=1; continue
        if obs!=pred:
            bad+=1
            print("  MISMATCH route",route)
            print("   pred",[x[:8] for x in pred])
            print("   obs ",[x[:8] for x in obs])
        else:
            print("  ok route",route)
    return bad
