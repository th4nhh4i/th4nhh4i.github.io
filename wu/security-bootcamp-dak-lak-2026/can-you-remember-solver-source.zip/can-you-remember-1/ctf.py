import json, os, hashlib, sys, time, urllib.parse, http.client
BASE="http://103.70.12.125:26001"

class _Resp:
    def __init__(self, status, body):
        self.status_code = status
        self.content = body
        self.text = body.decode("utf-8", "replace")
    def json(self):
        return json.loads(self.content.decode("utf-8"))

class _Session:
    def __init__(self):
        self.headers = {}
        self._conn = None
        self._origin = None
    def _request(self, method, url, payload=None):
        data = None
        headers = dict(self.headers)
        if payload is not None:
            data = json.dumps(payload).encode()
            headers["Content-Type"] = "application/json"
        u = urllib.parse.urlsplit(url)
        origin = (u.scheme, u.hostname, u.port or (443 if u.scheme == "https" else 80))
        path = urllib.parse.urlunsplit(("", "", u.path or "/", u.query, ""))
        for attempt in range(2):
            try:
                if self._conn is None or self._origin != origin:
                    if self._conn is not None:
                        self._conn.close()
                    cls = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
                    self._conn = cls(origin[1], origin[2], timeout=30)
                    self._origin = origin
                self._conn.request(method, path, body=data, headers=headers)
                r = self._conn.getresponse()
                body = r.read()
                status = r.status
                if r.will_close:
                    self._conn.close(); self._conn = None
                return _Resp(status, body)
            except (OSError, http.client.HTTPException):
                if self._conn is not None:
                    self._conn.close()
                self._conn = None
                if attempt:
                    raise
    def get(self, url):
        return self._request("GET", url)
    def post(self, url, json=None):
        return self._request("POST", url, json)

class Inst:
    def __init__(self, iid=None):
        self.s=_Session()
        if iid is None:
            iid=self.s.post(BASE+"/instance/start").json()["instance_id"]
        self.id=iid
        self.s.headers.update({"X-Instance-Id":iid})
        self.moves=None; self.hearts=None
    def _u(self,r):
        j=r.json()
        if "moves_remaining" in j: self.moves=j["moves_remaining"]
        if "hearts" in j: self.hearts=j["hearts"]
        return j
    def cur(self): return self._u(self.s.get(BASE+"/host/current"))
    def classify(self,f): return self._u(self.s.post(BASE+"/host/classify",json={"family":f}))
    def move(self,w): return self._u(self.s.post(BASE+"/move",json={"warp":w}))
    def reset(self): return self._u(self.s.post(BASE+"/reset"))
    def fetch(self,url):
        if url.startswith("/"): url=BASE+url
        return self.s.get(url).content

DB="famdb.json"
def loaddb():
    return json.load(open(DB)) if os.path.exists(DB) else {}
def savedb(d): json.dump(d,open(DB,"w"),indent=1,sort_keys=True)

SAMPLES="pool"
os.makedirs(SAMPLES,exist_ok=True)

def hostinfo(I):
    """Return (kind, sha256|None). Downloads+stores sample if new."""
    c=I.cur()
    if c["sample_url"] is None: return ("safe",None)
    blob=I.fetch(c["sample_url"])
    h=hashlib.sha256(blob).hexdigest()
    p=os.path.join(SAMPLES,h+".zip")
    if not os.path.exists(p): open(p,"wb").write(blob)
    return ("mal",h)
