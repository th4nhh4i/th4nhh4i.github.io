import json,time,random
import solve, explore7
from solve import Game, FAM, parse_route
from run_csp import csp, observed_fixed, walk, check_paths

BASE=solve.BASE

def solve_map(M,raw,observed):
    e=csp(M.nodes,raw,observed)
    if e is not None: return e,raw
    # Path/family traces are direct observations; tentative node identities are
    # only hints and can be wrong when local signatures collide.
    e=csp(M.nodes,{},observed)
    if e is not None: return e,{}
    # Retain the largest easy-to-check subset of tentative edge claims. The
    # no-trace CSP is tiny for this graph, so this remains bounded and avoids
    # the pathological relaxation search used by the first prototype.
    kept={}
    for key in sorted(raw,key=lambda k:len(M.nodes[k[0]]["path"])):
        trial=dict(kept); trial[key]=raw[key]
        if csp(M.nodes,trial,{}) is not None: kept[key]=raw[key]
    e=csp(M.nodes,kept,observed)
    return e,kept

def main():
    random.seed(0xC0FFEE)
    g=Game(); print("instance",g.I.id,time.strftime("%H:%M:%S"),flush=True)
    M=explore7.Mapper(g); M.discover()
    print("discovered",len(M.nodes),"moves",g.moves,"dl",g.dl,flush=True)
    json.dump([{"fam":n["fam"],"path":list(n["path"]),"ch":n["ch"],"nb":n["nb"]}
               for n in M.nodes],open("nodes_debug.json","w"),indent=1)
    if len(M.nodes)<20: print("not enough nodes"); return
    observed={}
    for p in M.path2n:
        seq=[]
        for k in range(len(p)+1):
            q=p[:k]; v=M.g.pathfam.get(q)
            if v is None: v=M.childfam.get(q)
            if v is None: v=M.nodes[M.path2n[q]]["fam"]
            seq.append(v)
        observed[p]=seq
    def trace(p):
        seq=[]
        for k in range(len(p)+1):
            q=p[:k]; v=M.g.pathfam.get(q)
            if v is None: v=M.childfam.get(q)
            if v is None and q in M.path2n: v=M.nodes[M.path2n[q]]["fam"]
            if v is None: return None
            seq.append(v)
        return seq
    raw=observed_fixed(M)
    edges,used=solve_map(M,raw,observed)
    if edges is None: print("initial CSP failed"); return
    ed={(i,w):edges[i][w] for i in range(20) for w in range(5)}
    print("initial map fixed",len(used),"path mismatches",len(check_paths(M,ed)),"moves",g.moves,flush=True)

    # Active offline-map refinement: every trace is gathered before the quiz,
    # then fed back as a Moore-machine constraint. Longer traces constrain
    # return-warp ambiguity more efficiently than short probes.
    good=0
    for t in range(45):
        route=tuple(random.randint(1,5) for _ in range(16))
        if g.moves is not None and g.moves<len(route)+12: break
        g.I.reset(); g.here=(); obs=[g.look()]
        for w in route:
            g.step(w); obs.append(g.look())
        observed[route]=obs
        pred=walk(ed,M.nodes,route)
        if pred==obs: good+=1
        edges,used=solve_map(M,raw,observed)
        if edges is None:
            observed.pop(route,None)
            print("refine conflict at",route,"(kept prior model)",flush=True)
            continue
        ed={(i,w):edges[i][w] for i in range(20) for w in range(5)}
        print("trace",t,"ok",pred==obs,"good",good,"moves",g.moves,flush=True)

    print("refined",good,"moves",g.moves,flush=True)
    qs=g.I.s.post(BASE+"/sanity-check/questions").json()
    json.dump(qs,open("questions.json","w"),indent=1)
    ans={}
    miss=0
    for q in qs:
        route=parse_route(q["route_map"]); seq=walk(ed,M.nodes,route)
        if seq is None: miss+=1; continue
        slugs=["safe" if f=="safe" else FAM[f] for f in seq]
        ans[q["id"]]=slugs if isinstance(q["answer_example"],list) else slugs[-1]
    print("unresolved",miss,flush=True)
    if miss: return
    r=g.I.s.post(BASE+"/sanity-check/submit",json=ans)
    print(r.status_code,r.text,flush=True)
    json.dump(ans,open("answers.json","w"),indent=1)
    open("result.json","w").write(r.text)

if __name__=="__main__": main()
