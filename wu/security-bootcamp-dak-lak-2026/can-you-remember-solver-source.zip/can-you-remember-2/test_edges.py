import json,time,collections
from run_csp import csp
n=json.load(open('nodes_extended.json'))
c=collections.defaultdict(list)
for i,x in enumerate(n): c[(x['fam'],tuple(x['ch']))].append(i)
u=sorted(v[0] for v in c.values()); m=[n[i] for i in u]
ti={ (x['fam'],tuple(x['ch'])):k for k,x in enumerate(m) }
pt={tuple(x['path']):ti[(x['fam'],tuple(x['ch']))] for x in n}
raw={}; conflicts=[]
for x in n:
    p=tuple(x['path']); cur=0
    for k,w in enumerate(p):
        a=pt[p[:k]]; b=pt[p[:k+1]]; key=(a,w-1)
        if key in raw and raw[key]!=b: conflicts.append((key,raw[key],b,p))
        raw[key]=b
print('types',len(m),'edges',len(raw),'conflicts',len(conflicts),flush=True)
t=time.time(); e=csp(m,raw,{}); print('csp raw',e is not None,time.time()-t,flush=True)
if e:
  print(e)
