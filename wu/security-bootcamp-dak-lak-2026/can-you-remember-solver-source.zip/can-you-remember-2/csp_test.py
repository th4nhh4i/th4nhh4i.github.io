import json,sys

nodes=json.load(open(sys.argv[1] if len(sys.argv)>1 else "nodes.json"))
n=len(nodes); fam=[x["fam"] for x in nodes]
ports=[(i,w) for i in range(n) for w in range(5)]
fixed={}
for i,x in enumerate(nodes):
    for k,v in x.get("nb",{}).items(): fixed[(i,int(k)-1)]=int(v)

def solve():
    used=set(); target=[set() for _ in range(n)]; assign={}
    def compatible(p,q):
        i,w=p; j,u=q
        if i==j: return False
        if fam[j]!=nodes[i]["ch"][w]: return False
        if fam[i]!=nodes[j]["ch"][u]: return False
        if target[i] and j in target[i]: return False
        if target[j] and i in target[j]: return False
        if (i,w) in fixed and fixed[(i,w)]!=j: return False
        if (j,u) in fixed and fixed[(j,u)]!=i: return False
        return True
    def dfs(left):
        if not left: return True
        best=None; opts=None
        for p in left:
            i,w=p
            cand=[]
            for q in left:
                if q==p: continue
                if compatible(p,q): cand.append(q)
            if opts is None or len(cand)<len(opts):
                best,opts=p,cand
                if not opts: return False
                if len(opts)==1: break
        p=best; i,w=p
        for q in opts:
            j,u=q
            used.add(p); used.add(q); assign[p]=j; assign[q]=i
            target[i].add(j); target[j].add(i)
            # cheap degree/domain forward check
            ok=True
            rem=left-{p,q}
            for r in rem:
                ri,rw=r
                if not any(compatible(r,s) for s in rem if s!=r):
                    ok=False; break
            if ok and dfs(rem): return True
            target[i].remove(j); target[j].remove(i)
            del assign[p]; del assign[q]; used.remove(p); used.remove(q)
        return False
    ok=dfs(set(ports))
    print("n",n,"ok",ok,"fixed",len(fixed))
    if ok:
        for i in range(n): print(i,[assign[(i,w)] for w in range(5)])
    return ok
solve()
