import json,time,random,collections,os
import solve, explore7
from solve import Game,FAM,parse_route
from run_csp import csp,walk

BASE=solve.BASE

def main():
    random.seed(0x5EED)
    iid=os.environ.get('CANREMEMBER_IID')
    g=Game(iid) if iid else Game()
    if iid:
        g.I.reset(); g.here=()
    print('instance',g.I.id,flush=True)
    M=explore7.Mapper(g); M.discover()
    # If early identification collapsed two hosts with the same first three
    # child families, probe the unresolved representative edges until all 20
    # full signatures are present or the safe move floor is reached.
    while True:
        sigs={(n['fam'],tuple(n['ch'])) for n in M.nodes}
        print('discovered',len(M.nodes),'unique',len(sigs),'moves',g.moves,flush=True)
        if len(sigs)>=20 or g.moves<160: break
        todo=[]
        for i,n in enumerate(M.nodes):
            for w in range(1,6):
                if w not in n['nb']:
                    todo.append((len(n['path']),i,w,tuple(n['path'])+(w,)))
        todo.sort()
        before=len(M.nodes)
        did=False
        for _,i,w,p in todo:
            if p in M.path2n: continue
            if g.moves<160: break
            M.nodes[i]['nb'][w]=M.identify(p,minw=3)
            did=True
            if len({(n['fam'],tuple(n['ch'])) for n in M.nodes})>=20: break
        if not did: break
    # Collapse repeated copies of an identical full signature. These copies
    # are observations of the same quotient state; each remaining signature
    # is one state in the 20-host automaton.
    sig_to_idx={}
    reps=[]
    for n in M.nodes:
        key=(n['fam'],tuple(n['ch']))
        if key not in sig_to_idx:
            sig_to_idx[key]=len(reps); reps.append(n)
    nodes=reps
    json.dump([{"fam":n["fam"],"path":list(n["path"]),"ch":n["ch"],"nb":n["nb"]}
               for n in M.nodes],open("nodes_debug.json","w"),indent=1)
    if len(nodes)!=20:
        print('not 20 unique signatures',len(nodes),flush=True); return
    # Every identified path gives a trusted family transition. Keep only
    # non-conflicting claims; do not use Mapper's tentative nb table.
    path_type={}
    path_fam={}
    for p,i in M.path2n.items():
        n=M.nodes[i]; key=(n['fam'],tuple(n['ch']))
        if key in sig_to_idx:
            path_type[tuple(p)]=sig_to_idx[key]; path_fam[tuple(p)]=n['fam']
    claimsets=collections.defaultdict(set)
    # Only the representative paths themselves are trusted here. Other
    # cached paths may have been assigned to an indistinguishable node after
    # only two child probes.
    trusted_paths={tuple(n['path']) for n in M.nodes}
    for p,b in path_type.items():
        if p not in trusted_paths: continue
        for k,w in enumerate(p):
            a=path_type.get(p[:k])
            if a is None: continue
            key=(a,w-1)
            claimsets[key].add(b)
    raw={k:next(iter(v)) for k,v in claimsets.items() if len(v)==1}
    conflicts=sum(1 for v in claimsets.values() if len(v)>1)
    print('model states',len(nodes),'fixed',len(raw),'conflicts',conflicts,'moves',g.moves,flush=True)
    e=csp(nodes,raw,{})
    if e is None:
        raw={}; e=csp(nodes,raw,{})
    if e is None:
        print('initial CSP failed',flush=True); return
    ed={(i,w):e[i][w] for i in range(20) for w in range(5)}
    observed={}
    good=0; tested=0
    # Use the remaining budget for active route constraints. Every route is
    # measured on the server, then used to select another compatible graph.
    for t in range(70):
        L=8
        if g.moves is not None and g.moves<L+10: break
        route=tuple(random.randint(1,5) for _ in range(L))
        g.I.reset(); g.here=(); obs=[g.look()]
        for w in route:
            g.step(w); obs.append(g.look())
        tested+=1
        pred=walk(ed,nodes,route)
        if pred==obs: good+=1
        trial=dict(observed); trial[route]=obs
        e2=csp(nodes,raw,trial)
        if e2 is None and raw:
            e2=csp(nodes,{},trial)
        if e2 is not None:
            observed=trial; ed={(i,w):e2[i][w] for i in range(20) for w in range(5)}
        print('trace',t,'ok',pred==obs,'good',good,'tested',tested,'moves',g.moves,'updated',e2 is not None,flush=True)
    print('refined',good,'/',tested,'moves',g.moves,flush=True)
    qs=g.I.s.post(BASE+'/sanity-check/questions').json()
    ans={}; miss=0
    for q in qs:
        route=parse_route(q['route_map']); seq=walk(ed,nodes,route)
        if seq is None: miss+=1; continue
        slugs=['safe' if f=='safe' else FAM[f] for f in seq]
        ans[q['id']]=slugs if isinstance(q['answer_example'],list) else slugs[-1]
    print('unresolved',miss,flush=True)
    if miss: return
    r=g.I.s.post(BASE+'/sanity-check/submit',json=ans)
    print(r.status_code,r.text,flush=True)
    json.dump(ans,open('answers.json','w'),indent=1)
    open('result.json','w').write(r.text)

if __name__=='__main__': main()
