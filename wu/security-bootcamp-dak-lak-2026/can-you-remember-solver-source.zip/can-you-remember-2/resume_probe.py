import json,random,time,os
import solve
from solve import Game,FAM,parse_route
from run_csp import csp,walk

BASE=solve.BASE

def model():
 n=json.load(open('nodes_debug.json'))
 ti={(x['fam'],tuple(x['ch'])):i for i,x in enumerate(n)}
 pt={tuple(x['path']):ti[(x['fam'],tuple(x['ch']))] for x in n}
 raw={}
 for x in n:
  p=tuple(x['path'])
  for k,w in enumerate(p):
   if p[:k] in pt and p[:k+1] in pt: raw[(pt[p[:k]],w-1)]=pt[p[:k+1]]
 return n,raw

def main():
 iid=os.environ['CANREMEMBER_IID']; n,raw=model(); g=Game(iid); g.I.reset(); g.here=()
 e=csp(n,raw,{}); ed={(i,w):e[i][w] for i in range(20) for w in range(5)}; obsall={}
 random.seed(1234)
 for t in range(6):
  route=tuple(random.randint(1,5) for _ in range(8)); g.I.reset(); g.here=(); obs=[g.look()]
  for w in route: g.step(w); obs.append(g.look())
  pred=walk(ed,n,route); print('route',t,'match',pred==obs,'moves',g.moves,flush=True)
  tr=dict(obsall); tr[route]=obs; start=time.time(); e2=csp(n,raw,tr); print('csp',e2 is not None,'seconds',round(time.time()-start,2),flush=True)
  if e2 is not None: obsall=tr; ed={(i,w):e2[i][w] for i in range(20) for w in range(5)}
 print('done',g.moves,flush=True)

if __name__=='__main__': main()
