import json,collections,time
n=json.load(open('nodes_debug.json')); N=len(n)
ti={(x['fam'],tuple(x['ch'])):i for i,x in enumerate(n)}
pt={tuple(x['path']):ti[(x['fam'],tuple(x['ch']))] for x in n}
fixed={}
for x in n:
    p=tuple(x['path'])
    for k,w in enumerate(p):
        if p[:k] in pt and p[:k+1] in pt:
            fixed[(pt[p[:k]],w-1)]=pt[p[:k+1]]
fam=[x['fam'] for x in n]
ports=[(i,w) for i in range(N) for w in range(5)]
pairdom={p:[] for p in ports}
for p in ports:
    i,w=p
    for q in ports:
        if q==p: continue
        j,u=q
        if i!=j and fam[j]==n[i]['ch'][w] and fam[i]==n[j]['ch'][u]:
            pairdom[p].append(q)
target=[set() for _ in range(N)]; assign={}; sols=[]; solset=set(); calls=0
def compat(p,q):
    i,w=p; j,u=q
    return fixed.get(p,j)==j and fixed.get(q,i)==i and j not in target[i] and i not in target[j]
def dfs(left):
    global calls
    calls+=1
    if len(sols)>=100000: return
    if not left:
        s=tuple(assign[(i,w)] for i in range(N) for w in range(5))
        if s not in solset: solset.add(s); sols.append(s)
        return
    best=min(left,key=lambda p:sum(1 for q in pairdom[p] if q in left and compat(p,q)))
    opts=[q for q in pairdom[best] if q in left and compat(best,q)]
    if not opts:return
    opts.sort(key=lambda q:len(pairdom[q]))
    for q in opts:
        i,w=best; j,u=q
        target[i].add(j); target[j].add(i); assign[best]=j; assign[q]=i
        rem=left-{best,q}; ok=True
        for r in rem:
            if not any(s in rem and compat(r,s) for s in pairdom[r]): ok=False; break
        if ok: dfs(rem)
        target[i].remove(j); target[j].remove(i); del assign[best]; del assign[q]
        if len(sols)>=100000:return
dfs(set(ports))
print('solutions',len(sols),'calls',calls,flush=True)
for k in range(min(10,len(sols))): print(k,sols[k][:25])
if sols:
    for z in range(100):
        vals={s[z] for s in sols}
        if len(vals)>1: print('vary',z,len(vals),vals)
