import json,random,time,os
import solve
from solve import Game,FAM,parse_route
from run_csp import csp,walk

BASE=solve.BASE

def make_model():
    n=json.load(open('nodes_debug.json'))
    ti={(x['fam'],tuple(x['ch'])):i for i,x in enumerate(n)}
    pt={tuple(x['path']):ti[(x['fam'],tuple(x['ch']))] for x in n}
    raw={}
    for x in n:
        p=tuple(x['path'])
        for k,w in enumerate(p):
            if p[:k] in pt and p[:k+1] in pt:
                raw[(pt[p[:k]],w-1)]=pt[p[:k+1]]
    return n,raw

def main():
    iid=os.environ['CANREMEMBER_IID']; nodes,raw=make_model()
    g=Game(iid); g.I.reset(); g.here=()
    e=csp(nodes,raw,{}); ed={(i,w):e[i][w] for i in range(20) for w in range(5)}
    observed={}; random.seed(0xA11CE); good=0; total=0
    for t in range(24):
        L=8
        if g.moves is not None and g.moves<L+12: break
        route=tuple(random.randint(1,5) for _ in range(L))
        g.I.reset(); g.here=(); seq=[g.look()]
        for w in route:
            g.step(w); seq.append(g.look())
        total+=1; pred=walk(ed,nodes,route)
        if pred==seq: good+=1
        trial=dict(observed); trial[route]=seq
        t0=time.time(); e2=csp(nodes,raw,trial)
        if e2 is not None:
            observed=trial; ed={(i,w):e2[i][w] for i in range(20) for w in range(5)}
        print('trace',t,'match',pred==seq,'good',good,'total',total,'updated',e2 is not None,'sec',round(time.time()-t0,2),'moves',g.moves,flush=True)
    print('refined',good,'/',total,'moves',g.moves,flush=True)
    qs=g.I.s.post(BASE+'/sanity-check/questions').json()
    ans={}; miss=0
    for q in qs:
        r=parse_route(q['route_map']); seq=walk(ed,nodes,r)
        if seq is None: miss+=1; continue
        slugs=['safe' if f=='safe' else FAM[f] for f in seq]
        ans[q['id']]=slugs if isinstance(q['answer_example'],list) else slugs[-1]
    print('unresolved',miss,flush=True)
    if miss: return
    r=g.I.s.post(BASE+'/sanity-check/submit',json=ans)
    print(r.status_code,r.text,flush=True)
    json.dump(ans,open('answers.json','w'),indent=1)
    open('result.json','w').write(r.text)

if __name__=='__main__': main()
