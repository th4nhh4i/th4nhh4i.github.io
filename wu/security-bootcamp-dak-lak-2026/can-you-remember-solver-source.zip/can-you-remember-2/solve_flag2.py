import json, time, random, collections, os, sys
sys.path.append(r'F:\Security BootCamp\bootcamp\bootcamp\canremember1\flag2_work_2026-09-10')
os.chdir(r'F:\Security BootCamp\bootcamp\bootcamp\canremember1\flag2_work_2026-09-10')

import solve, explore7
from solve import Game, FAM, parse_route
from ctf import BASE

def get_solutions(nodes, fixed_dict, observed_dict, max_sols=20, timeout_calls=250000):
    n = len(nodes)
    fam = [x["fam"] for x in nodes]
    ports = [(i, w) for i in range(n) for w in range(5)]
    
    pairdom = {p: [] for p in ports}
    for p in ports:
        i, w = p
        for q in ports:
            if q == p: continue
            j, u = q
            if i != j and fam[j] == nodes[i]["ch"][w] and fam[i] == nodes[j]["ch"][u]:
                pairdom[p].append(q)
                
    target = [set() for _ in range(n)]
    assign = {}
    sols = []
    calls = [0]
    
    def compat(p, q):
        i, w = p; j, u = q
        if fixed_dict.get(p, j) != j or fixed_dict.get(q, i) != i: return False
        if j in target[i] or i in target[j]: return False
        return True

    def partial_valid():
        if not observed_dict: return True
        for route, seq in observed_dict.items():
            cur = 0
            if fam[cur] != seq[0]: return False
            for k, w in enumerate(route, 1):
                key = (cur, w-1)
                if key not in assign: break
                cur = assign[key]
                if fam[cur] != seq[k]: return False
        return True

    def dfs(left):
        calls[0] += 1
        if calls[0] > timeout_calls: return False
        if len(sols) >= max_sols: return True
        if not left:
            if observed_dict:
                for route, seq in observed_dict.items():
                    cur = 0
                    if fam[cur] != seq[0]: return False
                    for k, w in enumerate(route, 1):
                        cur = assign[(cur, w-1)]
                        if fam[cur] != seq[k]: return False
            ed = {(i, w): assign[(i, w)] for i in range(n) for w in range(5)}
            sols.append(ed)
            return False

        best = None; opts = None
        # Observed route frontier priority
        if observed_dict:
            for route in sorted(observed_dict, key=len, reverse=True):
                cur = 0; frontier = None
                for w in route:
                    key = (cur, w-1)
                    if key not in assign:
                        frontier = key; break
                    cur = assign[key]
                if frontier is not None and frontier in left:
                    best = frontier
                    opts = [q for q in pairdom[best] if q in left and compat(best, q)]
                    break
                    
        if best is None:
            for p in left:
                op = [q for q in pairdom[p] if q in left and compat(p, q)]
                if opts is None or len(op) < len(opts):
                    best, opts = p, op
                    if not opts: return False
                    if len(opts) == 1: break

        if not opts: return False
        p = best; i, w = p
        random.shuffle(opts)
        for q in opts:
            j, u = q
            target[i].add(j); target[j].add(i)
            assign[p] = j; assign[q] = i
            rem = left - {p, q}
            ok = partial_valid()
            if ok:
                for r in rem:
                    if not any(s in rem and compat(r, s) for s in pairdom[r]):
                        ok = False; break
            if ok:
                if dfs(rem): return True
            target[i].remove(j); target[j].remove(i)
            del assign[p]; del assign[q]
            if len(sols) >= max_sols: return True
        return False

    dfs(set(ports))
    return sols

def walk(ed, nodes, route):
    cur = 0
    out = [nodes[cur]["fam"]]
    for w in route:
        cur = ed.get((cur, w-1))
        if cur is None: return None
        out.append(nodes[cur]["fam"])
    return out

def find_distinguishing_route(sols, nodes, max_len=7):
    if len(sols) <= 1:
        return None, 0
    best_route = None
    best_split = 0
    for _ in range(500):
        length = random.randint(3, max_len)
        route = tuple(random.randint(1, 5) for _ in range(length))
        preds = []
        for sol in sols:
            p = walk(sol, nodes, route)
            if p is not None:
                preds.append(tuple(p))
        if len(preds) < len(sols):
            continue
        counts = collections.Counter(preds)
        if len(counts) > 1:
            largest = counts.most_common(1)[0][1]
            split = len(sols) - largest
            if split > best_split:
                best_split = split
                best_route = route
                if split >= len(sols) // 2:
                    break
    return best_route, best_split

def main():
    random.seed(int(time.time()))
    print("==================================================", flush=True)
    print("=== Can You Remember 2 - Flag 2 Active Solver ===", flush=True)
    print("==================================================", flush=True)
    g = Game()
    print(f"Started instance: {g.I.id} at {time.strftime('%Y-%m-%d %H:%M:%S')}", flush=True)
    
    # Phase 1: Exploration & Node Discovery
    print("\n--- Phase 1: Node Discovery ---", flush=True)
    M = explore7.Mapper(g, verbose=True)
    M.discover(floor=180)
    
    while True:
        sigs = {(n['fam'], tuple(n['ch'])) for n in M.nodes}
        print(f"Discovered {len(M.nodes)} nodes, {len(sigs)} unique signatures, moves remaining: {g.moves}", flush=True)
        if len(sigs) >= 20 or (g.moves is not None and g.moves < 180):
            break
        todo = []
        for i, n in enumerate(M.nodes):
            for w in range(1, 6):
                if w not in n['nb']:
                    todo.append((len(n['path']), i, w, tuple(n['path']) + (w,)))
        todo.sort()
        did = False
        for _, i, w, p in todo:
            if p in M.path2n: continue
            if g.moves is not None and g.moves < 180: break
            M.nodes[i]['nb'][w] = M.identify(p, minw=3)
            did = True
            if len({(n['fam'], tuple(n['ch'])) for n in M.nodes}) >= 20:
                break
        if not did:
            break

    # Collapse repeated copies of identical full signatures
    sig_to_idx = {}
    reps = []
    for n in M.nodes:
        key = (n['fam'], tuple(n['ch']))
        if key not in sig_to_idx:
            sig_to_idx[key] = len(reps)
            reps.append(n)
    nodes = reps
    print(f"Automaton quotient states: {len(nodes)}, moves: {g.moves}", flush=True)
    if len(nodes) != 20:
        print(f"Warning: expected 20 states, got {len(nodes)}", flush=True)

    json.dump([{"fam": n["fam"], "path": list(n["path"]), "ch": n["ch"]} for n in nodes],
              open("nodes_discovered.json", "w"), indent=1)

    # Correct trusted transition extraction (BUGFIX: map prefix to next_prefix, NOT whole path!)
    path_type = {}
    for n in nodes:
        path_type[tuple(n['path'])] = sig_to_idx[(n['fam'], tuple(n['ch']))]
    for p, i in M.path2n.items():
        n = M.nodes[i]
        key = (n['fam'], tuple(n['ch']))
        if key in sig_to_idx:
            path_type[tuple(p)] = sig_to_idx[key]

    correct_raw = {}
    for p in path_type:
        for k, w in enumerate(p):
            prefix = p[:k]
            next_prefix = p[:k+1]
            if prefix in path_type and next_prefix in path_type:
                a = path_type[prefix]
                b = path_type[next_prefix]
                correct_raw[(a, w-1)] = b

    print(f"Correct trusted transitions: {len(correct_raw)} / 100", flush=True)

    # Phase 2: Active Learning Disambiguation
    print("\n--- Phase 2: Active Learning CSP Model Disambiguation ---", flush=True)
    observed = {}
    fixed_transitions = dict(correct_raw)
    
    # Check initial solvability
    sols = get_solutions(nodes, fixed_transitions, observed, max_sols=20)
    if not sols:
        print("Initial CSP with raw failed, falling back to empty fixed transitions", flush=True)
        fixed_transitions = {}
        sols = get_solutions(nodes, fixed_transitions, observed, max_sols=20)
    
    if not sols:
        print("CRITICAL: Initial CSP has no solutions!", flush=True)
        return

    final_model = sols[0]
    round_idx = 0
    max_rounds = 50
    while round_idx < max_rounds:
        round_idx += 1
        t0 = time.time()
        sols = get_solutions(nodes, fixed_transitions, observed, max_sols=20, timeout_calls=250000)
        dt = time.time() - t0
        
        if not sols and fixed_transitions:
            print(f"Round {round_idx}: No solutions with fixed transitions! Dropping fixed transitions...", flush=True)
            fixed_transitions = {}
            sols = get_solutions(nodes, fixed_transitions, observed, max_sols=20, timeout_calls=250000)
            
        if not sols:
            print(f"Round {round_idx}: Solver search exhausted. Proceeding with best model.", flush=True)
            break

        route, split = find_distinguishing_route(sols, nodes, max_len=7)
        if route is None or split == 0:
            print(f"\n>>> Round {round_idx}: All {len(sols)} sampled solutions agree on all test routes! <<<", flush=True)
            # Verification Gate: test on 3 live routes
            model = sols[0]
            all_passed = True
            for vt in range(3):
                if g.moves is not None and g.moves < 20:
                    break
                v_route = tuple(random.randint(1, 5) for _ in range(6))
                v_pred = walk(model, nodes, v_route)
                g.I.reset(); g.here = (); v_obs = [g.look()]
                for w in v_route:
                    g.step(w); v_obs.append(g.look())
                if v_pred != v_obs:
                    print(f"  Live verification route {v_route} FAILED! Adding to constraints...", flush=True)
                    observed[v_route] = v_obs
                    all_passed = False
                    break
                else:
                    print(f"  Live verification route {v_route} PASSED!", flush=True)
                    
            if all_passed:
                print(">>> 100% Model Confirmed on Live Verification! <<<", flush=True)
                final_model = model
                break
            else:
                continue
            
        if g.moves is not None and g.moves < len(route) + 25:
            print(f"Move budget low ({g.moves}), stopping active learning.", flush=True)
            final_model = sols[0]
            break

        # Query server for ground truth
        g.I.reset()
        g.here = ()
        obs = [g.look()]
        for w in route:
            g.step(w)
            obs.append(g.look())
            
        observed[route] = obs
        final_model = sols[0]
        print(f"Round {round_idx:2d}: route {route} (len {len(route)}), split {split}/{len(sols)}, solve {dt:.3f}s, moves left: {g.moves}", flush=True)

    # Phase 3: Sanity-Check Quiz Submission
    print("\n--- Phase 3: Final Model Verification & Quiz Submission ---", flush=True)
    print(f"Final graph model ready. Total verified server observations: {len(observed)}", flush=True)

    # Fetch and answer quiz
    print("\nFetching sanity-check questions...", flush=True)
    qs = g.I.s.post(BASE + "/sanity-check/questions").json()
    json.dump(qs, open("questions.json", "w"), indent=1)
    print(f"Received {len(qs)} questions.", flush=True)

    ans = {}
    unresolved = 0
    for q in qs:
        route = parse_route(q["route_map"])
        seq = walk(final_model, nodes, route)
        if seq is None:
            unresolved += 1
            print(f"Unresolved route for {q['id']}")
            continue
        slugs = ["safe" if f == "safe" else FAM.get(f, f) for f in seq]
        if isinstance(q["answer_example"], list):
            ans[q["id"]] = slugs
        else:
            ans[q["id"]] = slugs[-1]

    print(f"Unresolved questions: {unresolved}", flush=True)
    json.dump(ans, open("answers.json", "w"), indent=1)

    print("Submitting answers to server...", flush=True)
    res = g.I.s.post(BASE + "/sanity-check/submit", json=ans)
    print(f"Server response status: {res.status_code}", flush=True)
    print("Response text:", res.text, flush=True)
    open("result.json", "w").write(res.text)

    try:
        res_json = res.json()
        score = res_json.get("score")
        flag1 = res_json.get("flag_1")
        flag2 = res_json.get("flag_2")
        print("\n" + "="*50, flush=True)
        print(f"FINAL SCORE: {score}", flush=True)
        print(f"FLAG 1: {flag1}", flush=True)
        print(f"FLAG 2: {flag2}", flush=True)
        print("="*50 + "\n", flush=True)
    except Exception as e:
        print("Error parsing result JSON:", e, flush=True)

if __name__ == "__main__":
    main()
