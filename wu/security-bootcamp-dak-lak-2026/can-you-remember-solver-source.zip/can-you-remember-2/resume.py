import json, os, random, time
import solve
from solve import Game, FAM, parse_route
from run_csp import csp, walk

BASE=solve.BASE

def main():
    iid=os.environ.get("CANREMEMBER_IID")
    if not iid:
        print("set CANREMEMBER_IID", flush=True); return
    nodes=json.load(open("nodes_debug.json"))
    g=Game(iid)
    g.I.reset(); g.here=()
    print("resume",iid,"nodes",len(nodes),"moves",g.moves,flush=True)

    # The saved node table is from this exact instance.  Use only the family
    # signatures initially; the path-to-node guesses are deliberately omitted.
    observed={}
    edges=csp(nodes,{},observed)
    if edges is None:
        print("base CSP failed",flush=True); return
    ed={(i,w):edges[i][w] for i in range(20) for w in range(5)}
    random.seed(0xC0FFEE+2)
    good=0; seen=set()
    for t in range(40):
        L=16
        if g.moves is not None and g.moves<L+12: break
        while True:
            route=tuple(random.randint(1,5) for _ in range(L))
            if route not in seen: seen.add(route); break
        g.I.reset(); g.here=(); obs=[g.look()]
        for w in route:
            g.step(w); obs.append(g.look())
        pred=walk(ed,nodes,route)
        if pred==obs: good+=1
        observed[route]=obs
        nxt=csp(nodes,{},observed)
        if nxt is None:
            observed.pop(route)
            print("inconsistent trace",t,flush=True)
            continue
        edges=nxt; ed={(i,w):edges[i][w] for i in range(20) for w in range(5)}
        print("trace",t,"ok",pred==obs,"good",good,"moves",g.moves,flush=True)

    print("refined",good,"moves",g.moves,flush=True)
    qs=g.I.s.post(BASE+"/sanity-check/questions").json()
    ans={}; miss=0
    for q in qs:
        route=parse_route(q["route_map"]); seq=walk(ed,nodes,route)
        if seq is None:
            miss+=1; continue
        slugs=["safe" if f=="safe" else FAM[f] for f in seq]
        ans[q["id"]]=slugs if isinstance(q["answer_example"],list) else slugs[-1]
    print("unresolved",miss,flush=True)
    if miss: return
    r=g.I.s.post(BASE+"/sanity-check/submit",json=ans)
    print(r.status_code,r.text,flush=True)
    json.dump(ans,open("answers.json","w"),indent=1)
    open("result.json","w").write(r.text)

if __name__=="__main__": main()
