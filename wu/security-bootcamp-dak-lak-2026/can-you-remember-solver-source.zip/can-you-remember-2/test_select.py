import json,time,collections
from run_csp import csp
n=json.load(open('nodes_extended.json'))
c=collections.defaultdict(list)
for i,x in enumerate(n): c[(x['fam'],tuple(x['ch']))].append(i)
u=sorted(v[0] for v in c.values()); m=[n[i] for i in u]
pf={tuple(x['path']):x['fam'] for x in n}
items=[]
for x in n:
    p=tuple(x['path'])
    if all(p[:k] in pf for k in range(len(p)+1)):
        items.append((len(p),p,[pf[p[:k]] for k in range(len(p)+1)]))
items.sort()
print('types',len(m),'obs',len(items),flush=True)
obs={}
for z,(L,p,seq) in enumerate(items):
    obs[p]=seq
    t=time.time(); e=csp(m,{},obs); dt=time.time()-t
    print(z,L,p,'ok',e is not None,'sec',round(dt,3),flush=True)
    if e is None:
        obs.pop(p)
        print('discarded',p,flush=True)
