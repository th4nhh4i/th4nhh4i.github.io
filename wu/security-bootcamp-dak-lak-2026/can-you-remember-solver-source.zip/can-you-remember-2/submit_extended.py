import json, os, random
import solve
from solve import Game, FAM, parse_route
from run_csp import csp, walk

BASE=solve.BASE

def load_model():
    alln=json.load(open("nodes_extended.json"))
    bysig={}
    for i,n in enumerate(alln):
        bysig.setdefault((n["fam"],tuple(n["ch"])),i)
    reps=[bysig[k] for k in sorted(bysig)]
    nodes=[alln[i] for i in reps]
    tid={(n["fam"],tuple(n["ch"])):i for i,n in enumerate(nodes)}
    ptype={tuple(n["path"]):tid[(n["fam"],tuple(n["ch"]))] for n in alln}
    raw={}; conflicts=[]
    for n in alln:
        p=tuple(n["path"])
        for k,w in enumerate(p):
            key=(ptype[p[:k]],w-1); val=ptype[p[:k+1]]
            if key in raw and raw[key]!=val: conflicts.append((key,raw[key],val,p))
            raw[key]=val
    return nodes,raw,conflicts

def main():
    iid=os.environ.get("CANREMEMBER_IID")
    if not iid: print("set CANREMEMBER_IID"); return
    nodes,raw,conf=load_model()
    print("model",len(nodes),"claims",len(raw),"conflicts",len(conf),flush=True)
    e=csp(nodes,raw,{})
    if e is None: print("model CSP failed",flush=True); return
    ed={(i,w):e[i][w] for i in range(20) for w in range(5)}
    g=Game(iid); g.I.reset(); g.here=()
    observed={}
    # Spend a small amount of the remaining budget on independent validation.
    routes=[(1,1,1,1,1,1),(2,3,4,5,1,2),(3,2,5,4,3,1)]
    for route in routes:
        if g.moves is not None and g.moves<len(route)+4: break
        g.I.reset(); g.here=(); obs=[g.look()]
        for w in route:
            g.step(w); obs.append(g.look())
        pred=walk(ed,nodes,route)
        print("verify",route,"ok",pred==obs,"moves",g.moves,flush=True)
        observed[route]=obs
        if pred!=obs:
            e2=csp(nodes,raw,observed)
            if e2 is not None:
                e=e2; ed={(i,w):e[i][w] for i in range(20) for w in range(5)}
                print("model updated",flush=True)
            else:
                print("validation conflict",flush=True)
    qs=g.I.s.post(BASE+"/sanity-check/questions").json()
    ans={}; miss=0
    for q in qs:
        route=parse_route(q["route_map"]); seq=walk(ed,nodes,route)
        if seq is None: miss+=1; continue
        slugs=["safe" if f=="safe" else FAM[f] for f in seq]
        ans[q["id"]]=slugs if isinstance(q["answer_example"],list) else slugs[-1]
    print("unresolved",miss,flush=True)
    if miss: return
    r=g.I.s.post(BASE+"/sanity-check/submit",json=ans)
    print(r.status_code,r.text,flush=True)
    json.dump(ans,open("answers.json","w"),indent=1)
    open("result.json","w").write(r.text)

if __name__=="__main__": main()
