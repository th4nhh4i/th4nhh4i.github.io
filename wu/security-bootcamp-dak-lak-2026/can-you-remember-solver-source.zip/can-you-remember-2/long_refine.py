import json,random,time,os
import solve
from solve import Game,FAM,parse_route
from run_csp import csp,walk
BASE=solve.BASE

def make_model():
    n=json.load(open('nodes_debug.json')); ti={(x['fam'],tuple(x['ch'])):i for i,x in enumerate(n)}
    pt={tuple(x['path']):ti[(x['fam'],tuple(x['ch']))] for x in n}; raw={}
    for x in n:
        p=tuple(x['path'])
        for k,w in enumerate(p):
            if p[:k] in pt and p[:k+1] in pt: raw[(pt[p[:k]],w-1)]=pt[p[:k+1]]
    return n,raw
def main():
    iid=os.environ['CANREMEMBER_IID']; n,raw=make_model(); g=Game(iid); g.I.reset(); g.here=()
    e=csp(n,raw,{}); ed={(i,w):e[i][w] for i in range(20) for w in range(5)}; obsall={}
    random.seed(0xBEEF); good=0
    for t in range(6):
        L=20
        if g.moves is not None and g.moves<L+10: break
        route=tuple(random.randint(1,5) for _ in range(L)); g.I.reset();g.here=();obs=[g.look()]
        for w in route:g.step(w);obs.append(g.look())
        pred=walk(ed,n,route); good+=pred==obs; trial=dict(obsall);trial[route]=obs
        t0=time.time(); e2=None
        for attempt in range(2):
            e2=csp(n,raw,trial)
            if e2 is not None:break
        print('trace',t,'match',pred==obs,'good',good,'found',e2 is not None,'sec',round(time.time()-t0,2),'moves',g.moves,flush=True)
        if e2 is not None:obsall=trial;ed={(i,w):e2[i][w] for i in range(20) for w in range(5)}
    print('refined',good,'moves',g.moves,flush=True)
    qs=g.I.s.post(BASE+'/sanity-check/questions').json();ans={};miss=0
    for q in qs:
        r=parse_route(q['route_map']);seq=walk(ed,n,r)
        if seq is None:miss+=1;continue
        sl=['safe' if f=='safe' else FAM[f] for f in seq];ans[q['id']]=sl if isinstance(q['answer_example'],list) else sl[-1]
    print('unresolved',miss,flush=True)
    if not miss:
        r=g.I.s.post(BASE+'/sanity-check/submit',json=ans);print(r.status_code,r.text,flush=True);open('result.json','w').write(r.text);json.dump(ans,open('answers.json','w'),indent=1)
if __name__=='__main__':main()
