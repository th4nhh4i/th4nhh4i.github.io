import os,hashlib,json,io,zipfile,subprocess,tempfile,shutil
def blocks(d,B=512): return {hashlib.sha1(d[i:i+B]).digest()[:8] for i in range(0,len(d),B)}
def strip_overlay(d):
    i=d.rfind(b"PK\x05\x06")
    if i>0 and i>len(d)-4096:
        j=d.rfind(b"PK\x03\x04")
        if j>0 and j>len(d)-8192: return d[:j]
    return d
def upxd(d):
    if b"UPX!" not in d[:0x3000] and b"UPX0" not in d[:0x3000]: return d
    exe=shutil.which("upx")
    if exe is None:
        # Support both the development layout (../upx_dist) and the archived
        # self-contained solver snapshot (./upx_dist).
        candidates=[
            os.path.abspath(os.path.join(os.path.dirname(__file__),"..","upx_dist","upx-4.2.4-win64","upx.exe")),
            os.path.abspath(os.path.join(os.path.dirname(__file__),"upx_dist","upx-4.2.4-win64","upx.exe")),
        ]
        exe=next((p for p in candidates if os.path.exists(p)),None)
    if exe is None: return d
    with tempfile.NamedTemporaryFile(delete=False,suffix=".bin") as t: t.write(d); p=t.name
    try:
        r=subprocess.run([exe,"-d","-q",p],capture_output=True)
        return open(p,'rb').read() if r.returncode==0 else d
    finally:
        try: os.unlink(p)
        except: pass
def norm(d): return upxd(strip_overlay(d))
def inner(blob):
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        return z.read(z.namelist()[0], pwd=b"infected")
class Ident:
    def __init__(s, d="norm"):
        s.ref={}
        s.canon=json.load(open("canon.json")) if os.path.exists("canon.json") else {}
        dirs=[d, r"F:\Security BootCamp\bootcamp\bootcamp\canremember1\bins"]
        for root in dirs:
            if not os.path.isdir(root): continue
            for f in os.listdir(root):
                if f.endswith(".bin"):
                    key=f[:-4]
                    with open(os.path.join(root,f),'rb') as h: raw=h.read()
                    # Keep the raw references too: some server variants are UPX-packed,
                    # and the original corpus contains matching packed specimens.
                    s.ref[key]=blocks(norm(raw))
                    s.ref.setdefault(key+":raw",blocks(strip_overlay(raw)))
    def cid(s,data):
        b=blocks(norm(data)); best=None; bs=0.0
        for k,v in s.ref.items():
            u=len(b|v)
            if not u: continue
            j=len(b&v)/u
            if j>bs: bs=j; best=k
        if bs<0.80: return None,bs
        return s.canon.get(best.split(":",1)[0],best.split(":",1)[0]),bs
