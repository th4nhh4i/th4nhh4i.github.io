import json, os, time
import solve, explore7
from solve import Game

def main():
    iid=os.environ.get("CANREMEMBER_IID")
    if not iid: print("set CANREMEMBER_IID"); return
    raw=json.load(open("nodes_debug.json"))
    g=Game(iid); g.I.reset(); g.here=()
    M=explore7.Mapper(g)
    M.nodes=[{"fam":n["fam"],"path":tuple(n["path"]),"ch":list(n["ch"]),"nb":{int(k):v for k,v in n.get("nb",{}).items()}} for n in raw]
    for i,n in enumerate(M.nodes):
        M.path2n[n["path"]]=i
        M.g.pathfam[n["path"]]=n["fam"]
        for w,v in enumerate(n["ch"],1):
            M.childfam[n["path"]+(w,)]=v
    todo=[]
    for i,n in enumerate(M.nodes):
        for w in range(1,6):
            if w not in n["nb"]:
                todo.append((len(n["path"]),i,w,n["path"]+(w,)))
    todo.sort()
    print("extend",iid,"start nodes",len(M.nodes),"moves",g.moves,"todo",len(todo),flush=True)
    for _,i,w,p in todo:
        if len(M.nodes)>=30 or g.moves<60: break
        if p in M.path2n: continue
        before=len(M.nodes)
        j=M.identify(p,minw=2)
        M.nodes[i]["nb"][w]=j
        print("probe",p,"=>",j,"new",len(M.nodes)-before,"nodes",len(M.nodes),"moves",g.moves,flush=True)
    json.dump([{"fam":n["fam"],"path":list(n["path"]),"ch":n["ch"],"nb":n["nb"]} for n in M.nodes],open("nodes_extended.json","w"),indent=1)
    print("done nodes",len(M.nodes),"moves",g.moves,flush=True)

if __name__=="__main__": main()
