import json,time,random
import solve, explore7
from solve import Game, FAM, parse_route
BASE=solve.BASE
def main():
    g=Game(); print("instance",g.I.id,time.strftime("%H:%M:%S"),flush=True)
    open("run_instance","w").write(g.I.id)
    M=explore7.Mapper(g)
    M.discover()
    print("nodes",len(M.nodes),"moves",g.moves,"dl",g.dl,flush=True)
    missing=M.close_edges()
    dup,asym=M.consistency()
    print("consistency: dup",dup,"asym",asym,flush=True)
    print("missing edges",missing,"moves",g.moves,flush=True)
    nodes=M.nodes
    json.dump([{"fam":n["fam"],"path":list(n["path"]),"nb":{str(k):v for k,v in n["nb"].items()},
                "ch":n["ch"]} for n in nodes], open("nodes.json","w"),indent=1)
    if missing: print("!! incomplete map"); 
    # verify
    bad=0
    for t in range(4):
        if g.moves<20: break
        route=[random.randint(1,5) for _ in range(6)]
        pred=explore7.walk_predict(nodes,route)
        if pred is None: print("  unresolved route"); bad+=1; continue
        g.I.reset(); g.here=()
        obs=[g.look()]
        ok=True
        for w in route:
            f=g.look()
            if f!="safe":
                if not g.I.classify(FAM[f]).get("correct"): ok=False;break
            g.I.move(w); g.here=g.here+(w,)
            obs.append(g.look())
        if not ok: bad+=1; print("  classify fail"); continue
        if obs!=pred:
            bad+=1; print("  MISMATCH",route); print("   pred",[x[:8] for x in pred]); print("   obs ",[x[:8] for x in obs])
        else: print("  ok",route,flush=True)
    print("verify bad",bad,"moves",g.moves,flush=True)
    if bad or asym: print("ABORT: map inconsistent"); return
    qs=g.I.s.post(BASE+"/sanity-check/questions").json()
    json.dump(qs,open("questions.json","w"),indent=1)
    ans={}; miss=0
    for q in qs:
        r=parse_route(q["route_map"])
        seq=explore7.walk_predict(nodes,r)
        if seq is None: miss+=1; seq=[nodes[0]["fam"]]+[nodes[0]["fam"]]*len(r)
        slugs=[("safe" if f=="safe" else FAM.get(f,"wannacry")) for f in seq]
        ans[q["id"]]= slugs if isinstance(q["answer_example"],list) else slugs[-1]
    print("unresolved routes",miss,flush=True)
    json.dump(ans,open("answers.json","w"),indent=1)
    r=g.I.s.post(BASE+"/sanity-check/submit",json=ans)
    print(r.status_code); print(r.text[:4000]); open("result.json","w").write(r.text)
main()
